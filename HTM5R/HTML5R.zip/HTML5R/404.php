<?php get_header(); ?>
<?php get_sidebar(); ?>
<main id="content">

		<h2>Error 404 - Not Found</h2>
<p>Why not do a search on the site,  because
the page you're looking for doesn't exist. Don't you just hate that? I hate it almost as much as I hate: </p>
<ul>
<li>people who drive while yapping and gibbering into their cell phones, as if their stupid conversation or attempt to chat up their secretary into a torrid extra-marital shag were somehow more important than the safety of my 5 year old daughter as we walk to school</li>

<li>shell-suited workshy pasty-faced loutish uneducated fastfood-scoffing white-trash TV-junkie wankers who moan that immigrants are "taking our jobs". I wish they'd take your fucking house, too. And Liam and Chelsey, your feral children.</li>
<li>arseholes who drive too fast in residential areas at school time because they're late for their parasitic beancounting "jobs" as  auditers or human resource managers or telemarketers</li>
<li>no-dicked motherfuckers who razz up behind you when you're overtaking someone
  at 70 miles an hour in the outside lane, and sit 3 inches off your tail trying
  to bully you to speed up. Why don't they just drink rat poison, if they're
  that intent on killing themselves, instead of risking my family's lives too?</li>
<li>telemarketers and spammers</li>
<li>Bastards who drive in cities in monstrous cars with bullbars on the front  - like 21st century urban Britain is the fucking wild west. Twats.</li>
<li>Tossers who own dogs in the city and let them wander around shitting everywhere. If you think dog shit is so harmless, keep it in your own fucking garden. Or eat it, you filthy moron.</li>
<li>people who think that trampling on others in business is somehow laudable or demonstrates "good business sense". You can make a fortune performing backstreet abortions, selling smack or child porn but it doesn't mean you have to fucking DO it, does it?</li>
<li>the bastards at life insurance companies who won't insure me at anything less than a 50% hike in premiums because I have multiple sclerosis. YOU CAN'T FUCKING DIE FROM IT!</li>

<li>BUPA blue cross (see above).</li>

<li>George Dubya.</li>
<li>WhenI find myself humming some moron manufactured pop song like the Cheeky Girls or Atomic Kitten.</li>
<li>the fact that I still smoke cigarettes - or, more accurately, that I still occasionally <strong>enjoy</strong> it.</li>
<li>fuckwit psychobabble about "issues" and "closure" and "passive aggressive" and "sharing" and bullshit self-help books. Grow up, go down the pub with your mates and stop your whimpering narcissism.</li>
<li>People who give their kids stupidly variant-spelling names like 'Shevonne' instead of 'Siobhan', 'Dayzee' instead of 'Daisy'.</li>

<li>people who give their kids surnames as first names, like 'Mackenzie' or 'Madison'</li>
<li>people who give their kids place-names as first names, like 'Chester', 'Paris', 'Bethany' or -especially irritating - 'India' or 'Asia'. They should be forced to change their own name to <a href="http://travel.knowhere.co.uk/hotels/~thorngumbald/">'Thorngumbald'</a>, <a href="http://www.encyclopedia4u.com/p/pratt-s-bottom.html">'Pratts Bottom'</a>, or <a href="http://www.ee.surrey.ac.uk/Personal/R.Clarke/Pics/Cty_Durham/">'Swinket Mease Rigg'</a></li>

</ul>

<p>Phew, thanks for listening. Have a nice day, now. Missing you already. Thanks for letting me <em>share</em>.

  </p>
	</main>


<?php get_footer(); ?>
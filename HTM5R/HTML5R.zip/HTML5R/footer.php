<footer role="contentinfo">
  <p>
    <?php bloginfo('name'); ?>
    is copyright &copy; Bruce Lawson 2003-<?php echo date("Y");?>. Much (but not all)
    is available under a <a href="http://creativecommons.org/licenses/by-nc-nd/2.5/">creative
    commons license</a> that allows non-commercial attributed distribution. It's polite to ask me first, though.</p>
  <p>I work for <a href="http://www.opera.com/">Opera</a>, but all opinions contained herein are mine  (and are thus incontrovertibly
    correct) and do not represent the opinions of  my employers. (Comments are copyright their authors, not written by me, and
    are therefore probably the ramblings of mad people.)</p>
  <p><strong>Contact:</strong> bruce at this domain, or <a href="http://twitter.com/brucel">brucel on twitter</a>.</p>
</footer>

<!-- </div> </page> -->

<?php do_action('wp_footer'); ?>
<script src="http://cdn.lanyrd.net/badges/person-v1.min.js"></script>
</body></html>
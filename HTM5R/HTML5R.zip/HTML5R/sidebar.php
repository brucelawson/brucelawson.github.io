<aside role=complementary>
  <nav role=navigation>

    <div id=searchbox>
      <?php include (TEMPLATEPATH . '/searchform.php'); ?> 
    </div>

    <ul id=mainnav>
        <li><a id=home href="/"><span>Home</span></a></li>
        <li><a id=music href="/category/my-music/"><span>music</span></a></li>
        <li><a id=about href="/about/"> <span>about</span> </a></li>
        <li><a id=photos href="http://www.flickr.com/photos/24374884@N08/sets/"><span>photos</span></a></li>
        <li><a id=writing href="/writing/"><span>writing </span></a></li>
        <li><a id=navemail  href="/contact/"><span>email</span></a></li>
    </ul>

    <div id="lowlights">
      <h2>Site Lowlights:</h2>
      <ul>
        <li><a href="/archive/">Archives</a></li>
        <li><a href="/2004/zengarden/">Geocities 1996 - my CSS
          Zen Garden design</a></li>
        <li><a href="/spam-letters/">The Spam Letters</a></li>
        <li><a href="/kazaa/">Letters found on Kazaa</a></li>
        <li> <a href="http://www.amazon.co.uk/gp/registry/registry.html?ie=UTF8&amp;type=wishlist&amp;id=1X8A4ML6ZH3PQ"> My
          Amazon wishlist</a></li>
      </ul>
    </div>

  </nav>

  
    <!--  get the random image; hardcoded on my site  --> 
  <script src="/randompic.js">
  </script> 
    <!--end of random images -->
    <ul>
      <li><a href="http://www.nsdesign.co.uk/">Web Hosting by NSDesign.</a></li>
      <li>Proudly powered by <a href="http://wordpress.org">WordPress</a>. </li>
      <li><a href="feed:<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a> and <a href="feed:<?php bloginfo('comments_rss2_url'); ?>">Comments
        (RSS)</a>.</li>
    </ul>
    
  <!-- end colophon --> 
  
</aside>
